<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv='X-UA-Compitable' content="ie=edge">
        <meta name="viewport" content="width=device-width,initial-scale=1.0">
        <link rel="icon" href="images/favicon.ico">
        <link rel="stylesheet" href="<?php echo e(asset("cssfile/style.css")); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('cssfile/show.css')); ?>">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.8/css/line.css">
        <title>job posting</title>
    </head>
    <body>


<!-- =================NAVBAR=========================-->
        
<nav>
    <div class="container nav_container" >
        <div class="logo">
            <a href="/"><img src="<?php echo e(asset("images/laravel-logo.png")); ?>" alt="image"></a>
        </div>
        <div>
            <ul class="nav_menu">
                <?php if(auth()->guard()->check()): ?>
                <li><a href="/manage">Manage</a></li>
                <li>
                    <form action="/logout" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit">Logout</button>
                    </form>
                </li>
                <li><h3>Welcome <?php echo e(auth()->user()->name); ?></h3></li>
                <?php else: ?>
                <li><a href="/register">Register</a></li>
                <li><a href="/login">Login</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>



 <!--======================================SEARCH =============================-->
 <section class="search_bar">
    <div class="container search_container">
        <form action="/" method="GET">
            <div class="search">
                <span><i class="uil uil-search"></i></span>
                <input type="text" name="search" placeholder="larvel senior developer etc">
            </div>
            <button class="btn btn_primary" type="submit">search</button>
        </form>
    </div>
</section>




<!--============================ MAIN ============================-->
<main>
    <div class="container show_container">
        <div class="show_logo">
            <img src=<?php echo e($listing->logo?asset('/storage/'.$listing->logo):asset("images/acme.png")); ?> alt="image"> 
        </div>
        <div class="show_info">
            <h4><?php echo e($listing['title']); ?></h4>
            <h5><?php echo e($listing->company); ?></h5>
            <div><?php echo e($listing->location); ?></div>
            <ul class="tags">
                <?php
                    $tags=explode(',',$listing['tag']);
                    // echo $tags;
                ?>
                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><span><?php echo e($tag); ?></span></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <div>
                <div>Description</div>
                <?php echo e($listing['description']); ?>

            </div>
            <div><a href="email:<?php echo e($listing['email']); ?>">Contact Email: <?php echo e($listing['email']); ?></a></div>
            <div><a href="<?php echo e($listing['website']); ?>">visit: <?php echo e($listing['website']); ?></a></div>
        </div>
    </div>
</main>







<!-- ========================FOOTER =========================-->
<footer>
    <div class="container footer_container">
    <div class="copyright">
        copyright &copy; 2023 all right reserved
    </div>
    <div class="post_job">
        <a class="btn btn_primary" href="/create">Post Job</a>
    </div>
    </div>
</footer>
</body>
</html>
<?php /**PATH E:\raka\project\php\job_posting_website_laravel\job_posting\resources\views/show.blade.php ENDPATH**/ ?>