<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv='X-UA-Compitable' content="ie=edge">
        <meta name="viewport" content="width=device-width,initial-scale=1.0">
        <link rel="icon" href="images/favicon.ico">
        <link rel="stylesheet" href="<?php echo e(asset("cssfile/style.css")); ?>">
        <link rel="stylesheet" href="<?php echo e(asset("cssfile/login.css")); ?>">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.8/css/line.css">
        <title>job posting</title>
    </head>
    <body>

        <!-- =================NAVBAR=========================-->
        
        <nav>
            <div class="container nav_container" >
                <div class="logo">
                    <a href="/"><img src="<?php echo e(asset("images/laravel-logo.png")); ?>" alt="image"></a>
                </div>
                <div>
                    <ul class="nav_menu">
                        <li><a href="/manage">Manage</a></li>
                        <li><a href="/logout">Logout</a></li>
                        <li><h3>Welcome User</h3></li>
                    </ul>
                </div>
            </div>
        </nav>




        <!--=============================  LOGIN ======================-->
        <main>
            <div class="container login_container">
                <h4>Login</h4>
                <div>
                    <form action="/authenticate" method="POST">
                        <div>
                            <label for="email">Email: </label>
                            <input type="text" name="email">
                        </div>
                        <div>
                            <label for="password">Password: </label>
                            <input type="password" name="password">
                        </div>
                        <button class="btn btn_primary">Login</button>
                    </form>
                </div>
            </div>
        </main>


        









        <!-- ========================FOOTER =========================-->
        <footer>
            <div class="container footer_container">
            <div class="copyright">
                copyright &copy; 2023 all right reserved
            </div>
            <div class="post_job">
                <a class="btn btn_primary" href="/create">Post Job</a>
            </div>
            </div>
        </footer>
    </body>
</html><?php /**PATH E:\raka\project\php\job_posting_website_laravel\job_posting\resources\views//login.blade.php ENDPATH**/ ?>