<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv='X-UA-Compitable' content="ie=edge">
        <meta name="viewport" content="width=device-width,initial-scale=1.0">
        <link rel="icon" href="images/favicon.ico">
        <link rel="stylesheet" href="<?php echo e(asset("cssfile/style.css")); ?>">
    </head>
    <body>

        <!-- =================NAVBAR=========================-->
        
        <nav>
            <div class="container nav_container" >
                <div class="logo">
                    <img src="<?php echo e(asset("images/no-image.png")); ?>" alt="image">
                </div>
                <div>
                    <ul>
                        <li><a href="/manage">Manage</a></li>
                        <li><a href="/logout">Logout</a></li>
                        <li><h3>Welcome User</h3></li>
                    </ul>
                </div>
            </div>
        </nav>





        <!-- =================Header=========================-->
        <header>
            <div class="container header_container">
                <img src="images/laravel-logo.png" alt="image">
                <div>
                    <h2>JOB POSTING</h2>
                    <p>Find and post job and project</p>
                    <a class="btn" href="/register">Click here to sign up</a>
                </div>
            </div>
        </header>
        <section class="search-bar">
            <div class="container nav_container">
                <form action="/" method="GET">
                    <input type="text" name="search" placeholder="larvel senior developer etc">
                    <button class="btn btn_primary" type="submit">search</button>
                </form>
            </div>
        </section>







        <!-- =================Main=========================-->
        <main>
            <div class="container main_container">
                <div class="listing">
                    <div class="listing_log">
                        <img src="<?php echo e(asset('images/no-image.png')); ?>" alt="image">
                    </div>
                    <div>
                        <h3>Laravel senior developer</h3>
                        <h4>Company name</h4>
                        <p>location</p>
                        <p class="tags">
                            <span>tags</span>
                            <span>tags</span>
                            <span>tags</span>
                            <span>tags</span>
                        </p>
                    </div>
                </div>
                <div class="listing">
                    <div class="listing_log">
                        <img src="<?php echo e(asset('images/no-image.png')); ?>" alt="image">
                    </div>
                    <div>
                        <h3>Laravel senior developer</h3>
                        <h4>Company name</h4>
                        <p>location</p>
                        <p class="tags">
                            <span>tags</span>
                            <span>tags</span>
                            <span>tags</span>
                            <span>tags</span>
                        </p>
                    </div>
                </div>
                <div class="listing">
                    <div class="listing_log">
                        <img src="<?php echo e(asset('images/no-image.png')); ?>" alt="image">
                    </div>
                    <div>
                        <h3>Laravel senior developer</h3>
                        <h4>Company name</h4>
                        <p>location</p>
                        <p class="tags">
                            <span>tags</span>
                            <span>tags</span>
                            <span>tags</span>
                            <span>tags</span>
                        </p>
                    </div>
                </div>
                <div class="listing">
                    <div class="listing_log">
                        <img src="<?php echo e(asset('images/no-image.png')); ?>" alt="image">
                    </div>
                    <div>
                        <h3>Laravel senior developer</h3>
                        <h4>Company name</h4>
                        <p>location</p>
                        <p class="tags">
                            <span>tags</span>
                            <span>tags</span>
                            <span>tags</span>
                            <span>tags</span>
                        </p>
                    </div>
                </div>
                <div class="listing">
                    <div class="listing_log">
                        <img src="<?php echo e(asset('images/no-image.png')); ?>" alt="image">
                    </div>
                    <div>
                        <h3>Laravel senior developer</h3>
                        <h4>Company name</h4>
                        <p>location</p>
                        <p class="tags">
                            <span>tags</span>
                            <span>tags</span>
                            <span>tags</span>
                            <span>tags</span>
                        </p>
                    </div>
                </div>
            </div>
        </main>



        <!-- ========================FOOTER =========================-->
        <footer>
            <div>
                copyright &copy; 2023 all right reserved
            </div>
            <div>
                <a href="/create">Post Job</a>
            </div>
        </footer>
    </body>
</html><?php /**PATH E:\raka\project\php\job_posting_website\job_posting\resources\views/index.blade.php ENDPATH**/ ?>