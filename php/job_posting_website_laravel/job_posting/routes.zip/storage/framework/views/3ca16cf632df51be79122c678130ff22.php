<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv='X-UA-Compitable' content="ie=edge">
        <meta name="viewport" content="width=device-width,initial-scale=1.0">
        <link rel="icon" href="images/favicon.ico">
        <link rel="stylesheet" href="<?php echo e(asset("cssfile/style.css")); ?>">
        <link rel="stylesheet" href="<?php echo e(asset("cssfile/login.css")); ?>">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.8/css/line.css">
        <title>job posting</title>
    </head>
    <body>

        <!-- =================NAVBAR=========================-->
        
        <nav>
            <div class="container nav_container" >
                <div class="logo">
                    <a href="/"><img src="<?php echo e(asset("images/laravel-logo.png")); ?>" alt="image"></a>
                </div>
                <div>
                    <ul class="nav_menu">
                        <?php if(auth()->guard()->check()): ?>
                        <li><a href="/manage">Manage</a></li>
                        <li>
                            <form action="/logout" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit">Logout</button>
                            </form>
                        </li>
                        <li><h3>Welcome <?php echo e(auth()->user()->name); ?></h3></li>
                        <?php else: ?>
                        <li><a href="/register">Register</a></li>
                        <li><a href="/login">Login</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>




        <!--=============================  LOGIN ======================-->
        <main>
            <div class="container login_container">
                <h4>Login</h4>
                <div>
                    <form action="/authenticate" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form_item">
                            <div class="input">
                                <label for="email">Email: </label>
                                <input type="email" name="email" value="<?php echo e(old("email")); ?>">
                            </div>
                            <div class="error">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>{
                                    <?php echo e($message); ?>

                                }
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form_item">
                            <div class="input">
                                <label for="password">password: </label>
                                <input type="password" name="password" value="<?php echo e(old("password")); ?>">
                            </div>
                        </div>
                        <button class="btn btn_primary" type="submit">Login</button>
                    </form>
                </div>
                <div class="credentials">
                    <p>email: user@gmail.com  &nbsp password: 12345678</p>
                    <p>email: harry@gmail.com  &nbsp password: 12345678</p>
                </div>
            </div>
        </main>


        









        <!-- ========================FOOTER =========================-->
        <footer>
            <div class="container footer_container">
            <div class="copyright">
                copyright &copy; 2023 all right reserved
            </div>
            <div class="post_job">
                <a class="btn btn_primary" href="/create">Post Job</a>
            </div>
            </div>
        </footer>
    </body>
</html><?php /**PATH E:\raka\project\php\job_posting_website_laravel\job_posting\resources\views/login.blade.php ENDPATH**/ ?>