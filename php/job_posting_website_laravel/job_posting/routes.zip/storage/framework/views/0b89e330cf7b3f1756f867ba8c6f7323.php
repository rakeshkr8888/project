<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv='X-UA-Compitable' content="ie=edge">
        <meta name="viewport" content="width=device-width,initial-scale=1.0">
        <link rel="icon" href="images/favicon.ico">
        <link rel="stylesheet" href="<?php echo e(asset("cssfile/style.css")); ?>">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.8/css/line.css">
        
        <!--Alpine js-->
        <script src="//unpkg.com/alpinejs" defer></script>
        <title>job posting</title>
    </head>
    <body>

        <!-- =================NAVBAR=========================-->
        
        <nav>
            <div class="container nav_container" >
                <div class="logo">
                    <a href="/"><img src="<?php echo e(asset("images/laravel-logo.png")); ?>" alt="image"></a>
                </div>
                <div>
                    <ul class="nav_menu">
                        <?php if(auth()->guard()->check()): ?>
                        <li><a href="/manage">Manage</a></li>
                        <li>
                            <form action="/logout" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit">Logout</button>
                            </form>
                        </li>
                        <li><h3>Welcome <?php echo e(auth()->user()->name); ?></h3></li>
                        <?php else: ?>
                        <li><a href="/register">Register</a></li>
                        <li><a href="/login">Login</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>





        <!-- =================Header=========================-->
        <header>
            <div class="container header_container">
                
                    <div class="header_img">
                        <img src="images/no-image.png" alt="">
                    </div>
                    <ul class="header_content">
                        <li><h2>JOB POSTING</h2></li>
                        <li><p>Find and post job and project</p></li>
                        <?php if(auth()->guard()->check()): ?>
                        <?php else: ?>
                        <li><a class="btn" href="/register">Click here to sign up</a></li>
                        <?php endif; ?>
                    </ul>
                
            </div>
        </header>

        <!--======================================SEARCH =============================-->
        <section class="search_bar">
            <div class="container search_container">
                <form action="/" method="GET">
                    <div class="search">
                        <span><i class="uil uil-search"></i></span>
                        <input type="text" name="search" placeholder="larvel senior developer etc">
                    </div>
                    <button class="btn btn_primary" type="submit">search</button>
                </form>
            </div>
        </section>







        <!-- =================Main=========================-->
        <main>
            <div class="container main_container">
            <div class="listings">
                <?php if (! (count($listings)==0)): ?>
                <?php $__currentLoopData = $listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="listing">
                    <div class="listing_logo">
                        <img src="<?php echo e($listing->logo?asset('/storage/'.$listing->logo):asset('images/no-image1.png')); ?>" alt="image">
                    </div>
                    <div class="listing_info">
                        <a href="/show/<?php echo e($listing['id']); ?>"><h4><?php echo e($listing['title']); ?></h4></a>
                        <h5><i class="uil uil-building"></i><?php echo e($listing['company']); ?></h5>
                        <p><i class="uil uil-location-pin-alt"></i><?php echo e($listing['location']); ?></p>
                        <div class="tags">
                            <?php 
                                $tags=explode(",",$listing['tag']);
                            ?>
                            <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span><a href="?tag=<?php echo e($tag); ?>"><?php echo e($tag); ?></a></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <p>No listing found</p>
                <?php endif; ?>
            </div>
            <div>
                
            </div>
            </div>
        </main>



        <!-- ========================FOOTER =========================-->
        <footer>
            <div class="container footer_container">
            <div class="copyright">
                copyright &copy; 2023 all right reserved
            </div>
            <div class="post_job">
                <a class="btn btn_primary" href="/create">Post Job</a>
            </div>
            </div>
        </footer>

        <?php if(session()->has('message')): ?>
        <div x-data="{show: true}" x-init="setTimeout(() => show=false,3000)" x-show="show" class="flash_message">
            <p><?php echo e(session('message')); ?></p>
        </div>
        <?php endif; ?>
    </body>
</html><?php /**PATH E:\raka\project\php\job_posting_website_laravel\jobpostingpro\resources\views/index.blade.php ENDPATH**/ ?>